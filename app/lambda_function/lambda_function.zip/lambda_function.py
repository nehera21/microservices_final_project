import json
import boto3
import csv
import io
import uuid
from datetime import datetime

def lambda_handler(event, context):
    """
    Lambda function that gets triggered when a file is uploaded to S3.
    Detects simple anomalies in the data and stores them in DynamoDB.
    """
    # Get the S3 bucket and object key from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Initialize S3 and DynamoDB clients
    s3_client = boto3.client('s3')
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('anomalies')
    
    try:
        # Get the object from S3
        response = s3_client.get_object(Bucket=bucket, Key=key)
        
        # Read the content of the file
        file_content = response['Body'].read().decode('utf-8')
        
        # Parse the CSV content
        csv_reader = csv.reader(io.StringIO(file_content))
        
        # Get the header row to use as column names
        headers = next(csv_reader, None)
        if not headers:
            raise ValueError("CSV file is empty or has no headers")
        
        # Simple anomaly detection: look for rows with missing values or outliers
        anomalies = []
        row_num = 1  # Start at 1 for the data rows (after header)
        
        for row in csv_reader:
            row_num += 1
            
            # Check for missing values
            if len(row) < len(headers) or '' in row:
                anomalies.append({
                    'id': str(uuid.uuid4()),
                    'file_name': key,
                    'row_number': row_num,
                    'type': 'missing_value',
                    'description': f"Row {row_num} has missing values",
                    'row_data': ','.join(row),
                    'detected_at': datetime.now().isoformat()
                })
                continue
            
            # Check for numeric outliers in any numeric column
            for i, value in enumerate(row):
                # Skip non-numeric values
                try:
                    num_value = float(value)
                    
                    # Very simple outlier detection - values above 1000 or below 0
                    # You would customize this based on your actual data patterns
                    if num_value > 1000 or num_value < 0:
                        anomalies.append({
                            'id': str(uuid.uuid4()),
                            'file_name': key,
                            'row_number': row_num,
                            'column': headers[i],
                            'type': 'outlier',
                            'description': f"Value {num_value} in column {headers[i]} is an outlier",
                            'row_data': ','.join(row),
                            'detected_at': datetime.now().isoformat()
                        })
                except (ValueError, TypeError):
                    # Not a numeric value, skip
                    pass
        
        # Store anomalies in DynamoDB
        with table.batch_writer() as batch:
            for anomaly in anomalies:
                batch.put_item(Item=anomaly)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Successfully processed file from S3',
                'bucket': bucket,
                'key': key,
                'anomalies_found': len(anomalies)
            })
        }
    
    except Exception as e:
        print(f"Error processing file {key} from bucket {bucket}: {str(e)}")
        
        # Still try to record the error as an anomaly
        try:
            table.put_item(
                Item={
                    'id': str(uuid.uuid4()),
                    'file_name': key,
                    'type': 'processing_error',
                    'description': str(e),
                    'detected_at': datetime.now().isoformat()
                }
            )
        except Exception as db_error:
            print(f"Failed to record error in DynamoDB: {str(db_error)}")
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': f'Error processing file: {str(e)}',
                'bucket': bucket,
                'key': key
            })
        } 